namespace RoomsApiCrud.Models
{
    public interface IModel
    {
    }
}